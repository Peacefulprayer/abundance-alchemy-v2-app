import React from 'react';
import { Sparkles } from 'lucide-react';
import { buttonSoundService } from '../services/buttonSoundService';
import { SacredButton } from './ui/SacredButton';
import { href } from "../services/base";

interface PreSplashProps {
  onContinue: () => void;
  theme?: 'light' | 'dark';
}

export const PreSplash: React.FC<PreSplashProps> = ({ onContinue, theme = 'dark' }) => {
  const titleColor = theme === 'light' ? 'text-amber-500' : 'text-orange-400';
  const subTextColor = theme === 'light' ? 'text-yellow-600' : 'text-yellow-300';

  const handleContinue = () => {
    buttonSoundService.playClick();
    onContinue();
  };

  return (
    <div className="relative min-h-screen bg-slate-950 text-slate-100 px-6">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-slate-950 to-black" />
      {/* Soft glows */}
      <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-80 h-80 rounded-full bg-emerald-500/10 blur-3xl" />
      <div className="absolute bottom-0 right-0 w-72 h-72 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative z-10 min-h-screen max-w-md mx-auto grid grid-rows-[minmax(24px,1fr)_auto_auto_auto_auto_minmax(20px,1fr)]">
        {/* Top spacer */}
        <div />
<div className="flex items-center justify-center">
  <img
    src={href("assets/images/ui/orb_corona.gif")}
    width={130}
    height={130}
    alt=""
    aria-hidden
    className="pointer-events-none select-none"
    style={{ mixBlendMode: "screen", filter: "brightness(0.95)", opacity: 0.95 }}
  />
</div>
        {/* Logo */}
        <div className="flex justify-center">
          <img
            src="/logo.png"
            alt="Abundance Alchemy"
            className="h-10 w-auto drop-shadow-lg opacity-80"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = 'none';
            }}
          />
        </div>

        {/* Orb */}

        {/* Text */}
        <div className="text-center space-y-4">
          <h1 className={`text-xl font-serif font-bold ${titleColor}`}>Abundance Alchemy</h1>

          <div className="text-sm text-slate-300 leading-relaxed max-w-xs mx-auto space-y-1">
            <p>With Great Love, Welcome.</p>
            <p>We Are Honored, Standing Here With You</p>
            <p>As You Learn To Embrace The Power</p>
            <p>Of Your I Am Consciousness.</p>
          </div>

          <div className={`text-xs ${subTextColor} leading-relaxed max-w-xs mx-auto space-y-1`}>
            <p>Audio Enabled.</p>
            <p>Headphones Suggested.</p>
            <p>When Ready Click Next:</p>
          </div>
        </div>

        {/* Action */}
        <div className="flex justify-center">
          <SacredButton onClick={handleContinue} variant="primary" size="sm">
            <span>Next</span>
            <Sparkles className="w-4 h-4" />
          </SacredButton>
        </div>

        {/* Bottom spacer */}
        <div />
      </div>
    </div>
  );
};