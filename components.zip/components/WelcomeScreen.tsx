// src/components/WelcomeScreen.tsx - UPDATED VERSION
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AppMode, UserProfile } from '../types';
import BreathingOrb from './BreathingOrb'; // CHANGED: Use BreathingOrb instead of Orb
import { SacredButton } from './ui/SacredButton';
import { href } from '../services/base';

interface WelcomeScreenProps {
  user: UserProfile | null;
  onComplete: (nextMode: AppMode) => void;
}

const WELCOME_URL = href('assets/audio/voices/welcome.mp3');
const SPLASH_BG = href('assets/images/backgrounds/splash.jpg');

const PRE_AUDIO_PAUSE_MS = 500; // Half second pause before audio
const POST_AUDIO_PAUSE_MS = 700; // Pause after audio ends

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ user, onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [audioIntensity, setAudioIntensity] = useState(0);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationRef = useRef<number | null>(null);
  const finishedRef = useRef(false);

  const nextMode = useMemo(() => (user ? AppMode.DASHBOARD : AppMode.AUTH), [user]);

  // Audio analysis function
  const analyzeAudio = () => {
    if (!analyserRef.current || !isSpeaking || !audioRef.current) {
      setAudioIntensity(0);
      return;
    }

    try {
      const bufferLength = analyserRef.current.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      analyserRef.current.getByteFrequencyData(dataArray);
      
      // Calculate average intensity (0-1)
      let sum = 0;
      for (let i = 0; i < bufferLength; i++) {
        sum += dataArray[i];
      }
      const avg = sum / bufferLength;
      const normalizedIntensity = Math.min(avg / 255, 1);
      
      setAudioIntensity(normalizedIntensity);
      
      // Update progress
      const audio = audioRef.current;
      if (audio.duration > 0) {
        const currentProgress = (audio.currentTime / audio.duration) * 100;
        setProgress(currentProgress);
      }
    } catch (error) {
      console.warn('Audio analysis error:', error);
    }

    if (isSpeaking) {
      animationRef.current = requestAnimationFrame(analyzeAudio);
    }
  };

  useEffect(() => {
    finishedRef.current = false;

    const audio = new Audio(WELCOME_URL);
    audioRef.current = audio;
    
    let cancelled = false;
    let startTimeout: number | undefined;
    let endTimeout: number | undefined;

    const completeOnce = () => {
      if (cancelled || finishedRef.current) return;
      finishedRef.current = true;
      onComplete(nextMode);
    };

    const scheduleAfterBreath = () => {
      if (cancelled) return;
      endTimeout = window.setTimeout(() => {
        completeOnce();
      }, POST_AUDIO_PAUSE_MS);
    };

    const onPlay = () => {
      setIsSpeaking(true);
      // Start audio analysis
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      animationRef.current = requestAnimationFrame(analyzeAudio);
    };
    
    const onPause = () => {
      setIsSpeaking(false);
      setAudioIntensity(0);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
    
    const onEnded = () => {
      setIsSpeaking(false);
      setProgress(100);
      setAudioIntensity(0);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      scheduleAfterBreath();
    };

    const onError = (e: any) => {
      console.error('Audio error:', e);
      setIsSpeaking(false);
      // Auto-proceed if audio fails
      scheduleAfterBreath();
    };

    // Setup audio analysis if supported
    const setupAudioAnalysis = async () => {
      if (window.AudioContext || (window as any).webkitAudioContext) {
        try {
          const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
          const audioContext = new AudioContextClass();
          
          if (audioContext.state === 'suspended') {
            await audioContext.resume();
          }
          
          const analyser = audioContext.createAnalyser();
          analyser.fftSize = 256;
          analyser.smoothingTimeConstant = 0.8;
          analyserRef.current = analyser;
          
          const source = audioContext.createMediaElementSource(audio);
          source.connect(analyser);
          analyser.connect(audioContext.destination);
        } catch (audioCtxError) {
          console.warn('Audio analysis not available:', audioCtxError);
        }
      }
    };

    // Add event listeners
    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('error', onError);

    // Initialize and setup
    setupAudioAnalysis();

    // Sacred breath before audio (half second pause)
    startTimeout = window.setTimeout(() => {
      if (cancelled) return;

      audio.play().catch((error) => {
        console.log('Auto-play prevented:', error);
        // If auto-play fails, still proceed after pause
        setTimeout(() => {
          if (!cancelled && !finishedRef.current) {
            completeOnce();
          }
        }, 3000); // Give user 3 seconds to interact
      });
    }, PRE_AUDIO_PAUSE_MS);

    return () => {
      cancelled = true;
      if (startTimeout) clearTimeout(startTimeout);
      if (endTimeout) clearTimeout(endTimeout);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }

      try {
        audio.pause();
        audio.currentTime = 0;
      } catch {
        // ignore
      }

      audio.removeEventListener('play', onPlay);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('error', onError);

      audioRef.current = null;
      setIsSpeaking(false);
      setAudioIntensity(0);
    };
  }, [nextMode, onComplete]);

  const handleSkip = () => {
    // Stop audio immediately to prevent overlap
    try {
      audioRef.current?.pause();
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    } catch {
      // ignore
    }
    onComplete(nextMode);
  };

  return (
    <div className="relative min-h-screen bg-slate-950 text-slate-100">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${SPLASH_BG})`
        }}
      />
      <div className="absolute inset-0 bg-slate-950/80" />

      <div className="relative z-10 min-h-screen max-w-md mx-auto px-6 flex flex-col">
        {/* Top spacer - smaller since BreathingOrb is already in Layout */}
        <div className="h-8" />

        {/* Breathing Orb zone - CENTERED */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="mb-8">
            <BreathingOrb 
              isAudioPlaying={isSpeaking}
              audioIntensity={audioIntensity}
              size={140}
              breathingSpeed={4000}
              onClick={() => {
                // Optional: Add interaction
                console.log('Sacred Orb touched');
              }}
            />
          </div>

          {/* Title + invocation */}
          <div className="text-center mb-8">
            <h1 className="text-2xl font-light tracking-widest text-amber-400 mb-4">
              ABUNDANCE ALCHEMY
            </h1>

            <div className="text-sm text-slate-300 max-w-sm mx-auto leading-relaxed space-y-2">
              <p className="italic">We Are Honored To Welcome You.</p>
              <p>Let Us Pause A Moment.</p>
              <p>Take a sacred breath...</p>
              <p>Release and allow yourself to be immersed</p>
              <p>in this mystical invocation.</p>
              <p className="text-amber-300 mt-4">Ase.</p>
            </div>
          </div>

          {/* Progress visualization */}
          <div className="w-full max-w-xs mx-auto space-y-4">
            <div className="text-xs tracking-widest uppercase text-slate-400 text-center">
              SACRED INVOCATION
            </div>

            <div className="w-full h-1.5 rounded-full bg-slate-800/80 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-amber-400 via-orange-400 to-red-400 transition-all duration-150 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
            
            <div className="text-xs text-slate-500 text-center">
              {isSpeaking ? 'Playing sacred audio...' : 'Ready for your journey...'}
            </div>
          </div>
        </div>

        {/* Skip button */}
        <div className="pb-12 text-center space-y-4">
          <div className="flex justify-center">
            <SacredButton
              onClick={handleSkip}
              variant="primary"
              size="sm"
              className="tracking-widest text-xs px-6 py-2.5"
            >
              Continue Journey
            </SacredButton>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed max-w-xs mx-auto">
            Listen fully to the invocation, or continue now to begin your sacred practice.
          </p>
        </div>
      </div>
    </div>
  );
};