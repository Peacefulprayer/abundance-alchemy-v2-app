// src/components/AlchemistAvatar.tsx
import React from 'react';

interface AlchemistAvatarProps {
  speaking?: boolean;
  mood?: 'calm' | 'active' | 'gratitude';
  size?: 'sm' | 'md' | 'lg';
  progress?: number; // 0 to 1
  className?: string;
}

export const AlchemistAvatar: React.FC<AlchemistAvatarProps> = ({
  speaking = false,
  mood = 'active',
  size = 'md',
  progress = 0,
  className = ''
}) => {
  void mood;

  const sizeClasses: Record<'sm' | 'md' | 'lg', string> = {
    sm: 'w-24 h-24',
    md: 'w-44 h-44',
    lg: 'w-72 h-72'
  };

  const clampedProgress = Math.max(0, Math.min(1, progress));
  const showProgress = clampedProgress > 0;

  const radius = 46;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - clampedProgress);

  return (
    <div className={`relative flex items-center justify-center ${sizeClasses[size]} mx-auto ${className}`}>
      <style>{`
        @keyframes aa_breathe {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.018); }
        }
        @keyframes aa_breathe_speaking {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.034); }
        }
        @keyframes aa_haze {
          0%, 100% { transform: scale(1); opacity: .65; }
          50% { transform: scale(1.06); opacity: .85; }
        }
        @keyframes aa_haze_speaking {
          0%, 100% { transform: scale(1); opacity: .70; }
          50% { transform: scale(1.08); opacity: .95; }
        }
      `}</style>

      {/* Progress ring (only if used elsewhere) */}
      {showProgress && (
        <svg
          className="absolute inset-0 w-full h-full rotate-[-90deg] z-40 pointer-events-none"
          viewBox="0 0 100 100"
        >
          <circle cx="50" cy="50" r={radius} fill="none" stroke="currentColor" className="text-white/6" strokeWidth={0.5} />
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="none"
            className="text-amber-300/70 drop-shadow-[0_0_6px_rgba(255,255,255,0.25)]"
            strokeWidth={1.5}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
          />
        </svg>
      )}

      {/* Fire haze behind orb */}
      <div
        className="absolute inset-[-18%] rounded-full blur-3xl"
        style={{
          background:
            'radial-gradient(circle at 50% 52%, rgba(255,140,60,0.28) 0%, rgba(255,210,160,0.12) 34%, rgba(0,0,0,0) 70%)',
          animation: speaking ? 'aa_haze_speaking 2.6s ease-in-out infinite' : 'aa_haze 7.6s ease-in-out infinite'
        }}
      />

      {/* Orb */}
      <div
        className="relative z-10 rounded-full overflow-hidden bg-[#050608]"
        style={{
          width: '84%',
          height: '84%',
          animation: speaking ? 'aa_breathe_speaking 2.6s ease-in-out infinite' : 'aa_breathe 7.6s ease-in-out infinite'
        }}
      >
        {/* 3D depth */}
        <div className="absolute inset-0 bg-gradient-to-b from-white/12 via-transparent to-black/70" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_25%,rgba(255,255,255,0.10)_0%,transparent_42%)]" />

        {/* ONE ring near the edge */}
        <div className="absolute inset-[2.5%] rounded-full border border-white/20 shadow-[0_0_22px_rgba(255,170,90,0.18)]" />

        {/* subtle inner vignette */}
        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,transparent_46%,rgba(0,0,0,0.92)_100%)]" />
      </div>
    </div>
  );
};