import React from "react";

type Props = { active?: boolean; className?: string };

export function AuraBreathing({ active = false, className = "" }: Props) {
  return (
    <div className={`sacred-aura ${active ? "sacred-aura--active" : ""} ${className}`}>
      <div className="sacred-aura__layer sacred-aura__amber" />
      <div className="sacred-aura__layer sacred-aura__blue" />
      <div className="sacred-aura__layer sacred-aura__white" />
    </div>
  );
}

export default AuraBreathing;
