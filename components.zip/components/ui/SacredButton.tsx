import React from 'react';

type Variant = 'primary' | 'secondary';
type Size = 'sm' | 'md';

type Props = {
  children: React.ReactNode;
  onClick?: () => void;
  type?: 'button' | 'submit';
  disabled?: boolean;
  className?: string;
  variant?: Variant;
  size?: Size;
  fullWidth?: boolean;
};

const base =
  'inline-flex items-center justify-center gap-2 select-none ' +
  'rounded-full font-semibold tracking-[0.14em] uppercase ' +
  'transition-all duration-200 ' +
  'focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-200/50 ' +
  'disabled:opacity-50 disabled:cursor-not-allowed ' +
  // Apple-ish: keep refined visuals but reliable tap target
  'min-h-[44px]';

const sizeStyles: Record<Size, string> = {
  // refined, elegant
  sm: 'text-[11px] px-5 py-2',
  md: 'text-[12px] px-6 py-2.5'
};

const variants: Record<Variant, string> = {
  // screenshot colors, but polished
  primary:
    'bg-gradient-to-r from-amber-500 via-pink-500 to-violet-500 ' +
    'text-slate-950 border border-white/12 ' +
    'shadow-[0_14px_34px_rgba(0,0,0,0.55)] ' +
    'hover:brightness-105 active:brightness-95',
  // quiet but same silhouette/size
  secondary:
    'bg-slate-900/55 text-slate-100 border border-white/12 ' +
    'shadow-[0_12px_30px_rgba(0,0,0,0.45)] ' +
    'hover:bg-slate-900/70 active:bg-slate-900/80'
};

export const SacredButton: React.FC<Props> = ({
  children,
  onClick,
  type = 'button',
  disabled,
  className = '',
  variant = 'primary',
  size = 'sm',
  fullWidth = false
}) => {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={[
        base,
        sizeStyles[size],
        fullWidth ? 'w-full' : 'w-auto',
        variants[variant],
        className
      ].join(' ')}
    >
      {children}
    </button>
  );
};
