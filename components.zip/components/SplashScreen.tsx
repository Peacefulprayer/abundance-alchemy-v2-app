// src/components/SplashScreen.tsx
import React from 'react';
import { Sparkles } from 'lucide-react';
import Orb from "./Orb";
import { SacredButton } from './ui/SacredButton';
import { useAutoAdvance } from '../services/useAutoAdvance';
import { href } from '../services/base';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  // auto-advance after 500ms (CTA still available)
  useAutoAdvance(true, 500, onComplete);

  const handleEnter = () => onComplete();
  const bg = href('assets/images/backgrounds/SPLASH_1765630178_ai-generated-background-2.jpg');

  return (
    <div className="relative min-h-screen text-slate-100">
      {/* Background image + overlay */}
      <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${bg})` }} />
      <div className="absolute inset-0 bg-slate-950/70" />

      <div className="relative z-10 min-h-screen max-w-md mx-auto px-6 grid grid-rows-[minmax(18px,1fr)_minmax(120px,22vh)_auto_auto_auto_auto_minmax(16px,1fr)]">
        {/* Top spacer */}
        <div />

        {/* Orb + aura */}
    <div className="flex items-center justify-center">
  <div className="relative" /* ensure relative container */>
    <Orb speaking={false} sizePx={220} showParticles />
  </div>
</div>


        {/* Title */}
        <div className="text-center">
          <h1 className="text-xl font-serif font-bold text-orange-400">Abundance Alchemy</h1>
        </div>

        {/* Copy */}
        <div className="text-center text-sm text-slate-300 leading-relaxed max-w-xs mx-auto space-y-1">
          <p>The Process of Transformational Change</p>
          <p>Always Begins with Us</p>
          <p>Causing Transformational Shifting of Your Reality</p>
          <p>Through The Power Of Your I Am Consciousness.</p>
        </div>

        {/* Pills */}
        <div className="flex items-center justify-center">
          <div className="flex flex-nowrap gap-2">
            <div className="px-3 py-1.5 rounded-full border border-white/10 bg-slate-900/40 flex items-center gap-2">
              <Sparkles className="w-3 h-3 text-amber-300/90" />
              <span className="text-[10px] font-semibold tracking-[0.16em] uppercase text-amber-200">Affirmations</span>
            </div>

            <div className="px-3 py-1.5 rounded-full border border-white/10 bg-slate-900/40 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-200/70" />
              <span className="text-[10px] font-semibold tracking-[0.16em] uppercase text-amber-200">Meditation</span>
            </div>

            <div className="px-3 py-1.5 rounded-full border border-white/10 bg-slate-900/40 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-200/70" />
              <span className="text-[10px] font-semibold tracking-[0.16em] uppercase text-amber-200">Gratitude</span>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center space-y-3">
          <div className="text-[11px] tracking-[0.25em] uppercase text-slate-400">I Am Ready For Transformation</div>
          <div className="flex justify-center">
            <SacredButton onClick={handleEnter} variant="primary" size="sm">
              <span>Enter The Sacred Space</span>
              <Sparkles className="w-4 h-4" />
            </SacredButton>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center space-y-3">
          <p className="text-[12px] text-slate-500/80 leading-relaxed">
            Based on the book &quot;
            <a href="https://abundantthought.com" target="_blank" rel="noreferrer" className="font-bold text-orange-400 hover:text-orange-300 transition-colors">
              I Am Practice
            </a>
            &quot; by Michael Soaries.
          </p>

          <p className="text-[12px] text-slate-500/80 leading-relaxed">
            By continuing you agree to be a part of
            <br />
            the Abundant Thought Community and abide by community standards.
            <br />
            View our{' '}
            <a href="https://abundantthought.com" target="_blank" rel="noreferrer" className="underline decoration-white/20 hover:decoration-white/40 transition">
              privacy policy
            </a>{' '}
            here.
          </p>
        </div>

        {/* Bottom spacer */}
        <div />
      </div>
    </div>
  );
};
