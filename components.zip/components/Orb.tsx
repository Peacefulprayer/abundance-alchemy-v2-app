// src/components/Orb.tsx
import React from "react";

export type OrbProps = {
  speaking?: boolean;   // true → faster breathing
  showParticles?: boolean;
  sizePx?: number;      // override 180px if desired
  className?: string;   // outer wrapper (must be relative)
};

export default function Orb({
  speaking = false,
  showParticles = false,
  sizePx = 180,
  className = "",
}: OrbProps) {
  return (
    <div className={`relative ${className}`} style={{ width: sizePx, height: sizePx }}>
      {/* AURA */}
      <div className={`sacred-aura ${speaking ? "sacred-aura--active" : ""}`}>
        <div className="sacred-aura__layer sacred-aura__amber" />
        <div className="sacred-aura__layer sacred-aura__blue" />
        <div className="sacred-aura__layer sacred-aura__white" />
      </div>

      {/* ORB */}
      <div className="sacred-orb">
        {showParticles && (
          <div className="sacred-orb__particles">
            <div className="sacred-orb__particle" style={{ top: "40%", left: "20%", ["--tx" as any]: "30px", ["--ty" as any]: "-15px" }} />
            <div className="sacred-orb__particle" style={{ top: "60%", left: "70%", ["--tx" as any]: "-25px", ["--ty" as any]: "25px" }} />
            <div className="sacred-orb__particle" style={{ top: "20%", left: "50%", ["--tx" as any]: "15px", ["--ty" as any]: "30px" }} />
          </div>
        )}
      </div>
    </div>
  );
}
