// components/Button.tsx
import React from "react";

type Variant = "primary" | "secondary" | "ghost";

export type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
};

const VARIANTS: Record<Variant, string> = {
  primary: "bg-black text-white hover:opacity-90",
  secondary: "bg-gray-100 hover:bg-gray-200",
  ghost: "bg-transparent hover:bg-gray-100",
};

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = "primary", className = "", ...props },
  ref,
) {
  const base = "inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium transition";
  const styles = VARIANTS[variant];
  return <button ref={ref} className={`${base} ${styles} ${className}`} {...props} />;
});

export default Button;