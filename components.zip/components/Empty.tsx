// FILE: components/Empty.tsx
import React from "react";

export function Empty({
  title = "Nothing here yet",
  subtitle = "Try adjusting your input or come back later.",
  children,
}: { title?: string; subtitle?: string; children?: React.ReactNode; }) {
  return (
    <div className="border rounded-2xl p-8 text-center">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="text-sm opacity-80 mt-1">{subtitle}</p>
      {children ? <div className="mt-4">{children}</div> : null}
    </div>
  );
}
